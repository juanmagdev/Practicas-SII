package es.uma.informatica.sii.practica2.servicios.excepciones;

public class ContactoNoEncontrado extends RuntimeException {

}
